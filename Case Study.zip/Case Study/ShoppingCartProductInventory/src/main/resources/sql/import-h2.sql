INSERT INTO PRODUCT (product_id,name, description, quantity, price)
VALUES (1,'Soap', 'Pears baby soap for Kids', 100, 35.75);
INSERT INTO PRODUCT (product_id,name, description, quantity, price)
VALUES (2,'Tooth Brush', 'Signal Tooth Brushes Size', 150, 34.50);
INSERT INTO PRODUCT (product_id,name, description, quantity, price)
VALUES (3,'Shirt', 'Casual Shirt imported from France', 130, 1500.00);
INSERT INTO PRODUCT (product_id,name, description, quantity, price)
VALUES (4,'Office Bag', 'Leather bag imported from USA', 40, 1000.00);
INSERT INTO PRODUCT (product_id,name, description, quantity, price)
VALUES (5,'Bottle', 'Hot Water Bottles', 80, 450.45);
INSERT INTO PRODUCT (product_id,name, description, quantity, price)
VALUES (6,'Wrist Watch', 'Imported wrist watches from swiss', 80, 2500.00);
INSERT INTO PRODUCT (product_id,name, description, quantity, price)
VALUES (7,'Mobile Phone', '3G/4G capability', 20, 45000.00);
INSERT INTO PRODUCT (product_id,name, description, quantity, price)
VALUES (8,'Shampoo', 'Head and Shoulders Shampoo', 150, 300.00);
INSERT INTO PRODUCT (product_id,name, description, quantity, price)
VALUES (9,'Leather Wallets', 'Imported Leather Wallets from AUS', 50, 500.00);
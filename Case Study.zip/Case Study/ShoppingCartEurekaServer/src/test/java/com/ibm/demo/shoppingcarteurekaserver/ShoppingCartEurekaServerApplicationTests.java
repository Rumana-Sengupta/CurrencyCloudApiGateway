package com.ibm.demo.shoppingcarteurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.ibm.demo.shoppingcartapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartApiGatetewayApplicationTests {

	@Test
	void contextLoads() {
	}

}

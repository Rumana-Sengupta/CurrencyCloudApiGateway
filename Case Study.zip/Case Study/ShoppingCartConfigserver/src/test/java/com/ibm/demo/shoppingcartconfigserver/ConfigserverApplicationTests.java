package com.ibm.demo.shoppingcartconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartConfigserverApplicationTests {

	@Test
	void contextLoads() {
	}

}

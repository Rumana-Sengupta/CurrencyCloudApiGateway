package com.ibm.demo.shoppingcartorder.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.ibm.demo.shoppingcartorder.model.Cart;
import com.ibm.demo.shoppingcartorder.model.CartDTO;
import com.ibm.demo.shoppingcartorder.model.CartLineInfo;
import com.ibm.demo.shoppingcartorder.model.CoreResponseModel;
import com.ibm.demo.shoppingcartorder.model.FinalOrder;
import com.ibm.demo.shoppingcartorder.model.OrderDTO;
import com.ibm.demo.shoppingcartorder.model.Product;
import com.ibm.demo.shoppingcartorder.model.ProductDefaultPrice;
import com.ibm.demo.shoppingcartorder.model.Product;
import com.ibm.demo.shoppingcartorder.repo.ShoppingCartDefaultProductPriceRepository;
import com.ibm.demo.shoppingcartorder.repo.ShoppingCartOrderRepository;
import com.ibm.demo.shoppingcartorder.repo.ShoppingCartRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.RequiredArgsConstructor;


@Component
@RibbonClient(name = "shoppingcartproductinventory")
@RequiredArgsConstructor
@Service
public class ShoppingCartOrderService {
	
	@Autowired
	private ShoppingCartOrderRepository  orderrepo;
	
	@Autowired
	private ShoppingCartRepository cartrepo;
	
	@Autowired
	private ShoppingCartDefaultProductPriceRepository defaultPriceRepo;
	
	@Autowired
	private CoreResponseModel respModel;	
	
	private ResponseEntity<?>  respEntity;
	
	private  Cart myCart = new Cart();
	
	private List<ProductDefaultPrice> defaultPriceList = new ArrayList<ProductDefaultPrice>();
	
  

	@Bean
	@LoadBalanced
	RestTemplate createRestTemplate() {
		RestTemplateBuilder b = new RestTemplateBuilder();
		populateDufaultPrices();
		return b.build();
	}

	@Autowired
	@Lazy
	RestTemplate lbrestTemplate;
	
	
	
	public Cart getMyCart() {
		return myCart;
	}

	public List<ProductDefaultPrice> getDefaultPriceList() {
		return defaultPriceList;
	}

	public void setDefaultPriceList(List<ProductDefaultPrice> defaultPriceList) {
		this.defaultPriceList = defaultPriceList;
	}

	public void setMyCart(Cart myCart) {
		populateDufaultPrices();
		this.myCart = myCart;
	}
	
	public void populateDufaultPrices(){
		List<ProductDefaultPrice> defaultPriceList   = defaultPriceRepo.findAll();
		this.setDefaultPriceList(defaultPriceList);
	}

	private static org.slf4j.Logger log = LoggerFactory.getLogger(ShoppingCartOrderService.class);
	
	
	@HystrixCommand(fallbackMethod = "getDefaultPrice")
	public FinalOrder confirmorder(String customerId) 	{
		FinalOrder finalOrder = new FinalOrder();
		finalOrder.setUserid(customerId);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"); 
		finalOrder.setDate(formatter.format(new Date()));
		
		String baseUrl = "http://shoppingcartproductinventory/inventory/findproduct/{productid}";
		
		Product product = null;
		Double price = 0.00;
		String description = "";
		for(CartLineInfo cartLineInfo : myCart.getCartLines()) {
			Map<String, Integer> params = new HashMap<String, Integer>();
		    params.put("productid", cartLineInfo.getProductID());	
		    product = lbrestTemplate.getForObject(baseUrl, Product.class, params);
		    price =  price + ( cartLineInfo.getQuantity() * product.getPrice());		  
		    description = description + cartLineInfo.getQuantity()+"--"+ product.getDescription()+"--";;
			
		}		
		
		finalOrder.setTotalprice(price);
		finalOrder.setDescription(description);
		orderrepo.save(finalOrder);
		cartrepo.deleteById(myCart.getId());
		return finalOrder;
	}
 
	public FinalOrder getDefaultPrice(String customerId) {		
	
		FinalOrder finalOrder = new FinalOrder();
		finalOrder.setUserid(customerId);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"); 
		finalOrder.setDate(formatter.format(new Date()));		
	
		Double price = 0.00;
		String description = "";
		for(CartLineInfo cartLineInfo : myCart.getCartLines()) {
			if(defaultPriceList.size()>0) {
				ProductDefaultPrice productDefaultPrice = defaultPriceRepo.findByProductId(cartLineInfo.getProductID());
				  for(ProductDefaultPrice defaultPricedata : defaultPriceList) {
					  if(defaultPricedata.getProductId()==cartLineInfo.getProductID()) {
						   price =  price + ( cartLineInfo.getQuantity() * productDefaultPrice.getPrice());
						    description = description + cartLineInfo.getQuantity()+"--"+ productDefaultPrice.getDescription()+"--";;
                            break;
						  
					  }
				  }			   
				
			}else {				
				
				break;
			}
			
			
			
		}
		finalOrder.setTotalprice(price);
		finalOrder.setDescription(description);
		orderrepo.save(finalOrder);
		return finalOrder;
	}
	
	
	public ResponseEntity<?> addtocart(List<CartLineInfo> cartLines , String customerId) {
		Cart myCart = new Cart();
		try {			
			myCart.setCustomerId(customerId);
			myCart.setCartLines(cartLines);
			cartrepo.save(myCart);
		} catch (Exception ex) {
			return populateFailureResponse(ex.getMessage());
			
		}
		this.setMyCart(myCart);
		return populateSuccessResponseWithResult(myCart, "Successfully Update records to database");
	}
	
	
	public ResponseEntity<?> updatetocart(List<CartLineInfo> cartLines , String customerId) {
		try {
			Cart myCart = cartrepo.findByCustomerId(customerId);
			if(null == myCart) {
				Cart myCartL = new Cart();
				myCartL.setCustomerId(customerId);
				myCartL.setCartLines(cartLines);
				myCart=cartrepo.save(myCartL);
			}else {
				
				for(CartLineInfo cartLine : cartLines) {
					
					boolean existInCart = false;
					
					for(CartLineInfo myCartLine : myCart.getCartLines()) {
						if(myCartLine.getProductID() == cartLine.getProductID()) {
							myCartLine.setQuantity(cartLine.getQuantity()+myCartLine.getQuantity());
							existInCart = true;
							break;
						}
						
					}
					if(!existInCart) {
						myCart.getCartLines().add(cartLine);
					}
					
				}
				
				cartrepo.save(myCart);
				
			}
			log.info(" Record Updated Successfully");
			return populateSuccessResponseWithResult(myCart, "Successfully Update records to database");
		} catch (Exception ex) {
			return populateFailureResponse(ex.getMessage());
		}

		//return ResponseEntity.ok("successfully added in DB");
	}
	
	public ResponseEntity<?> findcart(String customerId) {
		   Cart cart = cartrepo.findByCustomerId(customerId);
		   if(null != cart) {
			   return populateSuccessResponseWithResult(cart, "Successfully Fetch Cart  for" + customerId);  
		   }else {
			   return populateSuccessResponseWithResult(cart, "Nothing in Cart for " + customerId);
		   }
		  
		   
	}
	
	
   public FinalOrder findorder(String customerId) {
	   
	  
		return orderrepo.findByUserid(customerId);
	}
	
	
	public ResponseEntity<?>   populateSuccessResponseWithResult(Object result, String message){		
		
		respModel = new CoreResponseModel();
		respModel.setStatusCode(200);
		respModel.setMessage(message);
		respModel.setResponseBody(result);
		respEntity = new ResponseEntity<Object>(respModel,HttpStatus.OK);
		return respEntity;
	}
	
	public ResponseEntity<?>  populateFailureResponse( String message){	
		respModel = new CoreResponseModel();
		respModel.setStatusCode(HttpStatus.BAD_REQUEST.value());
		respModel.setMessage(message);
		respModel.setSuccess(false);		
		respEntity = new ResponseEntity<Object>(respModel,HttpStatus.BAD_REQUEST);		
		return respEntity;
	}

}

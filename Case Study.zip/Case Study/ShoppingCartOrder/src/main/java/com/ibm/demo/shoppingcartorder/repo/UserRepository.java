package com.ibm.demo.shoppingcartorder.repo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.ibm.demo.shoppingcartorder.model.User;

@Component
public class UserRepository {
	
	private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	HashSet<String> user1 = new HashSet<String>(); 
	HashSet<String> user2 = new HashSet<String>();
	
	private User[] users = {new User("john", "John Mathew",encoder.encode("Test123"),user1), 
			new User("ramesh", "Ramesh Kumar",encoder.encode("Test123"),user2)};
	
	
	public User findByUserName(String name) {
		return Stream.of(users).filter(user -> user.getUserName().equalsIgnoreCase(name)).findAny().orElse(null);
	}
	

}
